/// <reference path="../app.ts" />

'use strict';

angular.module('<%= scriptAppName %>')
  .constant('<%= cameledName %>', 42);
