'use strict';

/**
 * @ngdoc function
 * @name <%= scriptAppName %>.controller:<%= classedName %>Ctrl
 * @description
 * # <%= classedName %>Ctrl
 * Controller of the <%= scriptAppName %>
 */
angular.module('<%= scriptAppName %>')
  .controller('<%= classedName %>Ctrl','<%= classedName %>Ctrl');
  

   /** @ngInject */
   function <%= classedName %>Ctrl($scope,<%= classedName %>Service){
    /**
    * Funcion de Inicio del Componente Sin la Generacion del HTML
    */
    this.$onInit = function () {
      console.log('OnInitEvent<%= classedName %>Ctrl');
    }; 
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
