'use strict';

/**
 * @ngdoc directive
 * @name <%= scriptAppName %>.directive:<%= cameledName %>
 * @description
 * # <%= cameledName %>
 */
angular.module('<%= scriptAppName %>')
  .directive('<%= cameledName %>',<%= cameledName %>);
  
  /** @ngInject */
  function <%= cameledName %>() {
    var jqWindow = $(window);
    return {
      template: '<div></div>',
      templateUrl:'',
      restrict: 'E',
      controller: <%= cameledName %>Ctrl,
      link: function postLink(scope, element, attrs) {
        element.text('this is the <%= cameledName %> directive');

        this.$onInit = function () {
          console.log('OnInitEvent<%= classedName %> directive');
          $('#Objeto').on('click', function ($evt) {
            return _on<%= cameledName %>ElementClick($evt) ;
          } );
        }; 

    /**
    * Funcion de Inicio del Componente despues de la Generacion del HTML
    */
        element.ready(function(){
          return $onInit();
        });


        jqWindow.on('click', _onWindowClick);

        scope.$on('$destroy', function() {
          jqWindow.off('click', _onWindowClick);
        });

        function _onWindowClick($evt) {};
        
        function _on<%= cameledName %>ElementClick($evt) {
          console.log('on<%= cameledName %>ElementClick');
      };
      };

  };
