# <%= _.slugify(_.humanize(appname)) %>

This project is generated with [yo angular generator](https://github.com/yeoman/generator-angular)
version <%= pkg.version %>.

## Build & development

Run `grunt` for building and `grunt serve` for preview.

## Testing

Running `grunt test` will run the unit tests with karma.
