'use strict';

var path = require('path');
var util = require('util');
var ScriptBase = require('../script-base.js');
var yeoman = require('yeoman-generator');
var Generator = module.exports = function Generator() {
  yeoman.generators.NamedBase.apply(this, arguments);
  console.log(arguments.store);
  ScriptBase.apply(this, arguments);
 // this.sourceRoot(path.join(__dirname, '..'));
};

util.inherits(Generator, ScriptBase);

Generator.prototype.createQxComponentFiles = function createQxComponentFiles() {

  //console.log(this);
  var tempname = this.cameledName;
  console.log(tempname);
  //this.name = this.tempname + "Directive";
  this.generateqxSourceAndTest(
    'directive',
    'spec/directive',
    '',
    this.options['skip-add'] || false
  );

  //this.name = this.tempname + "Controller";
  this.generateqxSourceAndTest(
    'controller',
    'spec/controller',
    '',
    this.options['skip-add'] || false
  );

  //this.name = this.tempname + "Service";
  this.generateqxSourceAndTest(
    'service/service',
    'spec/service',
    '',
    this.options['skip-add'] || false
  );

};

//this.sourceRoot(path.join(__dirname, '../templates/common'));
//util.inherits(Generator, yeoman.generators.NamedBase);

Generator.prototype.createViewFiles = function createViewFiles() {
  this.template(
    '/app/views/view.html',
    path.join(
      this.env.options.appPath,
      this.name,
      this.name.toLowerCase() + '.html'
    )
  );
};

/*
var Generator2 = module.exports = function Generator() {
  yeoman.generators.NamedBase.apply(this, arguments);

  this.sourceRoot(path.join(__dirname, '../templates/common'));
/*
  if (typeof this.env.options.appPath === 'undefined') {
    this.env.options.appPath = this.options.appPath;

    if (!this.env.options.appPath) {
      try {
        this.env.options.appPath = require(path.join(process.cwd(), 'bower.json')).appPath;
      } catch (e) {}
    }
    this.env.options.appPath = this.env.options.appPath || 'app';
    //this.options.appPath = this.env.options.appPath;
  }
};
*/
/*
util.inherits(Generator, yeoman.generators.NamedBase);

Generator2.prototype.createViewFiles = function createViewFiles() {
  this.template(
    'app/views/view.html',
    path.join(
      this.env.options.appPath,
      'views',
      this.name.toLowerCase() + '.html'
    )
  );
};
*/