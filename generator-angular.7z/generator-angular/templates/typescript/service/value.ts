/// <reference path="../app.ts" />

'use strict';

angular.module('<%= scriptAppName %>')
  .value('<%= cameledName %>', 42);
